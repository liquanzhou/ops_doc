<?php
require_once('fastdfs.php');

$fdfs = new FDFS();
$group_name = 'group2';
$localfile = './logo_www.gif';
$fileinfo = $fdfs->upload($localfile);

if ($fileinfo) {
  // update file info in the database etc
}

var_dump($fileinfo);
